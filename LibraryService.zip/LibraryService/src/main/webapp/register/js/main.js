$(function(){
	$.validate({
        modules : 'security'
    });
})
package ir.ghee.model.entity;

import com.google.gson.Gson;
import jakarta.persistence.*;
import jakarta.persistence.Table;
import lombok.*;
import org.hibernate.annotations.*;
import org.hibernate.annotations.CascadeType;


@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder

@Entity(name = "personEntity")
@Table(name = "personTbl")
public class Person {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(columnDefinition = "NVARCHAR2(20)")
    private String name;

    @Column(columnDefinition = "NVARCHAR2(20)")
    private String family;

    @Column(columnDefinition = "CHAR(10)",unique = true)
    private String nC_Code;

    @Column(columnDefinition = "NVARCHAR2(12)",unique = true)
    private String PhoneNumber;

    @OneToOne
    @JoinColumn(name = "user_id")
//    @Cascade(CascadeType.ALL)
    private User user;


    public Person(String name, String family, String nC_Code, String phoneNumber, User user) {
        this.name = name;
        this.family = family;
        this.nC_Code = nC_Code;
        PhoneNumber = phoneNumber;
        this.user = user;
    }

    @Override
    public String toString() {
        return new Gson().toJson(this);
    }


}

package ir.ghee.model.service;

import ir.ghee.model.entity.Borrow;
import ir.ghee.model.repository.CrudRepository;

import java.util.List;

public class BorrowService implements ServiceImpl<Borrow,Integer>{
    private static BorrowService borrowService = new BorrowService();

    private BorrowService() {
    }

    public static BorrowService getBorrowService() {
        return borrowService;
    }

    @Override
    public Borrow save(Borrow borrow) throws Exception {
        try(CrudRepository<Borrow,Integer> borrowDA = new CrudRepository<>()){
            return borrowDA.save(borrow);
        }
    }

    @Override
    public Borrow update(Borrow borrow) throws Exception {
        try(CrudRepository<Borrow,Integer> borrowDA = new CrudRepository<>()){
            return borrowDA.update(borrow);
        }
    }

    @Override
    public Borrow delete(Integer id) throws Exception {
        try(CrudRepository<Borrow, Integer> borrowDA = new CrudRepository<Borrow, Integer>()){
            return borrowDA.delete(Borrow.class,id);
        }
    }

    @Override
    public Borrow findById(Integer id) throws Exception {
        try(CrudRepository<Borrow,Integer> borrowDA = new CrudRepository<>()){
            return borrowDA.findById(Borrow.class,id);
        }
    }

    @Override
    public List<Borrow> findAll() throws Exception {
        try(CrudRepository<Borrow,Integer> borrowDA = new CrudRepository<>()){
            return borrowDA.selectAll(Borrow.class);
        }
    }
}

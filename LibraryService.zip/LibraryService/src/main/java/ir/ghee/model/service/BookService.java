package ir.ghee.model.service;

import ir.ghee.model.entity.Book;
import ir.ghee.model.repository.CrudRepository;

import java.util.List;

public class BookService implements ServiceImpl<Book,Integer> {
    private static BookService bookService = new BookService();

    private BookService() {
    }

    public static BookService getBookService() {
        return bookService;
    }

    @Override
    public Book save(Book book) throws Exception {
        try(CrudRepository<Book,Integer> bookDA = new CrudRepository<>()){
            return bookDA.save(book);
        }
    }

    @Override
    public Book update(Book book) throws Exception {
        try(CrudRepository<Book,Integer> bookDA = new CrudRepository<>()){
            return bookDA.update(book);
        }
    }

    @Override
    public Book delete(Integer id) throws Exception {
        try(CrudRepository<Book, Integer> bookDA = new CrudRepository<Book, Integer>()){
            return bookDA.delete(Book.class,id);
        }
    }

    @Override
    public Book findById(Integer id) throws Exception {
        try(CrudRepository<Book,Integer> bookDA = new CrudRepository<>()){
            return bookDA.findById(Book.class,id);
        }
    }

    @Override
    public List<Book> findAll() throws Exception {
        try(CrudRepository<Book,Integer> bookDA = new CrudRepository<>()){
            return bookDA.selectAll(Book.class);
        }
    }


}

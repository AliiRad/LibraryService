package ir.ghee.model.utils;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class JPA {
    private static JPA jpa = new JPA();
    private EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("persistence");

    private JPA() {
    }

    public static JPA getJpa() {
        return jpa;
    }

    public EntityManager getEntityManager (){
        return entityManagerFactory.createEntityManager();
    }
}

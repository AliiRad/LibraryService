package ir.ghee.model.entity;

import com.google.gson.Gson;
import jakarta.persistence.*;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder


@Entity(name = "borrowEntity")
@Table(name = "borrowTbl")

public class Borrow {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private int id;

    @OneToOne
    @JoinColumn(name = "user_id")
    private User user;

    @OneToOne
    @JoinColumn(name = "book_id")
    private Book book;

    @Override
    public String toString() {
        return new Gson().toJson(this);
    }

    public Borrow(User user, Book book) {
        this.user = user;
        this.book = book;
    }

}
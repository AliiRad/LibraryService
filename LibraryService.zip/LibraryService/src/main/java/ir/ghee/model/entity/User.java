package ir.ghee.model.entity;

import com.google.gson.Gson;
import jakarta.persistence.*;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder

@Entity(name = "userEntity")
@Table(name = "userTbl")
@NamedQuery(name = "user.findByUsernamePassword" , query = "select user from userEntity user where user.username=:username and user.password=:password")
@NamedQuery(name = "user.findDelete" , query = "select user from userEntity user where user.username=:username and user.password=:password and user.status=true")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(columnDefinition = "VARCHAR2(20)",unique = true)
    private String username;

    @Column(columnDefinition = "VARCHAR2(20)",unique = true)
    private String password;

    private boolean status;

    public User(String username, String password, boolean status) {
        this.username = username;
        this.password = password;
        this.status = status;
    }

    @Override
    public String toString() {
        return new Gson().toJson(this);
    }

}

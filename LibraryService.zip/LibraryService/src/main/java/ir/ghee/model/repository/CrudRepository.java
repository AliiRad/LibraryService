package ir.ghee.model.repository;

import ir.ghee.model.utils.JPA;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Query;

import java.util.List;
import java.util.Map;

public class CrudRepository<T,I> implements AutoCloseable {

    EntityManager entityManager = JPA.getJpa().getEntityManager();

    public T save (T t){
        EntityTransaction entityTransaction = entityManager.getTransaction();
        entityTransaction.begin();
        entityManager.persist(t);
        entityTransaction.commit();
        return t;
    }

    public T update(T t){
        EntityTransaction entityTransaction = entityManager.getTransaction();
        entityTransaction.begin();
        entityManager.merge(t);
        entityTransaction.commit();
        return t;
    }

    public T delete(Class<T> tClass,I id){
        EntityTransaction entityTransaction = entityManager.getTransaction();
        entityTransaction.begin();
        T t = entityManager.find(tClass,id);
        entityManager.remove(t);
        entityTransaction.commit();
        return t;
    }

    public T findById(Class<T> tClass, I id) {
        entityManager = JPA.getJpa().getEntityManager();
        T entity = entityManager.find(tClass, id);
        return entity;
    }

    public List<T> selectAll(Class<T> tClass) {
        entityManager = JPA.getJpa().getEntityManager();
        String sql = "select entity from " + tClass.getAnnotation(Entity.class).name() + " entity ";
        Query query =
                entityManager
                        .createQuery(sql);
        List<T> tList = query.getResultList();
        return tList;
    }

    public T executeQuery(String queryName, Map<String, Object> paramMap) {
        entityManager = JPA.getJpa().getEntityManager();
        Query query =
                entityManager
                        .createNamedQuery(queryName);
        if (paramMap != null) {
            for (String key : paramMap.keySet()) {
                query.setParameter(key, paramMap.get(key));
            }
        }

        T result = (T) query.getSingleResult();
        return (result.toString().length() > 0 ? result : null);
    }

    @Override
    public void close() throws Exception {
        entityManager.close();
    }


//    public static void main(String[] args) {
//        User user = new User("ghazal","ghazal123",false);
//        Person person = new Person("ghazal","rsl","0151458744","090356884521",user);
//        CrudRepository<Person,Long> userDA = new CrudRepository<>();
//        System.out.println(userDA.save(person));
//        System.out.println(userDA.selectAll(Person.class));
//    }
}

package ir.ghee;

import ir.ghee.controller.BorrowController;
import ir.ghee.controller.EntityController;
import ir.ghee.model.service.UserService;

public class Main {
    public static void main(String[] args) throws Exception {
        EntityController entityController = new EntityController();
        System.out.println(entityController.save("ali", "rad", "0151451771", "09300925677", "ali", "ali123"));
//        System.out.println(entityController.removeUser(1L));


    }
}

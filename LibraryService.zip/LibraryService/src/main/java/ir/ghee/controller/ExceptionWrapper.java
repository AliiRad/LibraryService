package ir.ghee.controller;

import java.sql.SQLException;

public class ExceptionWrapper {
    private static ExceptionWrapper exceptionWrapper = new ExceptionWrapper();

    private ExceptionWrapper() {
    }

    public static ExceptionWrapper getExceptionWrapper() {
        return exceptionWrapper;
    }

    public String getMessage(Exception e){
        if (e instanceof SQLException){
            return "SQL Error : " + e.getMessage();
        } else if (e instanceof RuntimeException) {
            return "runTime error :"+ e.getMessage();
        }else{
            return "error : "+ e.getMessage();
        }
    }
}

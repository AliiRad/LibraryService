package ir.ghee.controller;

import ir.ghee.model.entity.Person;
import ir.ghee.model.entity.User;
import ir.ghee.model.service.PersonService;
import ir.ghee.model.service.UserService;

public class EntityController {
    public String save(String name,String family,String nC_Code,  String phoneNumber,String username , String password){
        try{

            if (name != null && family != null && nC_Code.length() == 10 && phoneNumber.length() == 11  && username != null && password != null ){
                User user = new User(username,password,false);
                Person person = new Person(name,family,nC_Code,phoneNumber,user);
                UserService.getUserService().save(user);
                PersonService.getPersonService().save(person);
                return "Saved";

            }else{
                return "some parameter is null";
            }

        }catch (Exception e){
            e.printStackTrace();
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }

    public String findByUserPass(String username,String password){
        try{
            String result = UserService.getUserService().findByUsernamePass(username,password).toString();
            if(result != null){
                return "person Finded :" + result;
            }else{
                return "person doesn't Find ";
            }

        }catch (Exception e){
            return null;
        }
    }



    public String removeUser(Long id){
        try {
            if (UserService.getUserService().findById(id) != null){
                String answer = UserService.getUserService().delete(id).toString();
                return "delete";
            }else{
                return "User does not exist";
            }
        }catch (Exception e){
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }
}

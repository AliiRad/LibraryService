package ir.ghee.controller;

import ir.ghee.model.entity.Book;
import ir.ghee.model.entity.Borrow;
import ir.ghee.model.entity.User;
import ir.ghee.model.service.BookService;
import ir.ghee.model.service.BorrowService;
import ir.ghee.model.service.UserService;

import java.util.List;

public class BorrowController {
    public String save(String username , String password ,int book_id){
        try {
            EntityController entityController = new EntityController();
            User user = UserService.getUserService().findByUsernamePass(username, password);
            Book book = BookService.getBookService().findById(book_id);
            Borrow borrow = new Borrow(user,book);
            return BorrowService.getBorrowService().save(borrow).toString();
        }catch (Exception e){
            e.printStackTrace();
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }

    public String addBook(String name,String author){
        try {
            Book book = new Book(name,author);
            return BookService.getBookService().save(book).toString();
        }catch(Exception e){
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }

    public String remove (int id){
        try {
            if(BookService.getBookService().delete(id) != null ) {
                return "remove";
            }else{
                return "error in remove";
            }
        }catch (Exception e){
            e.printStackTrace();
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }

    public String findById(int id){
        try {
            String book =  BookService.getBookService().findById(id).toString();
            if (book != null){
                return "Book find";
            }else{
                return null;
            }
        }catch(Exception e){
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }


}

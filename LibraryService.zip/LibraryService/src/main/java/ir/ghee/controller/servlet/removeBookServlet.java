package ir.ghee.controller.servlet;

import ir.ghee.controller.BorrowController;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(urlPatterns = "/removeBook")
public class removeBookServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        BorrowController borrowController = new BorrowController();
        if (borrowController.remove(id).equals("remove")){
            resp.sendRedirect("/adminBooks.jsp");
        }else{
            resp.getWriter().write(borrowController.remove(id));
        }
    }
}

package ir.ghee.controller.servlet;

import ir.ghee.controller.BorrowController;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(urlPatterns = "/addBook")
public class BookServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("name");
        String author = req.getParameter("author");
        if (name.length()>2 && author.length()>2) {
            BorrowController borrowController = new BorrowController();
            borrowController.addBook(name, author);
            resp.sendRedirect("/admin.jsp");
        }else{
            resp.getWriter().write("invalid name and author");
        }
    }
}

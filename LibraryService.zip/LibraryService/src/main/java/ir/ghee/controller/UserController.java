package ir.ghee.controller;

import ir.ghee.model.service.UserService;

public class UserController {
    public String findDelete(String username,String password){
        try {
            if (UserService.getUserService().findDelete(username,password) != null) {
                return "user deleted";
            }else{
                return "user is active";
            }
        }catch (Exception e){
            return  ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }

//    public static void main(String[] args) {
//        UserController userController = new UserController();
//        System.out.println(userController.findDelete("ali", "asdd"));
//    }
}
